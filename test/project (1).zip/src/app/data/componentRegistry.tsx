import React from 'react';
import svgPaths from "../../imports/svg-d0oi33duag";

export const ComponentRegistry: Record<string, { label: string; component: React.ComponentType<any> }> = {
    'ClassicApp': { label: 'Classic App Layout', component: React.lazy(() => import('../components/ClassicApp').then(module => ({ default: module.ClassicApp }))) },
    'Cn': { label: 'Sidebar Layout', component: React.lazy(() => import('../../imports/RecipeSiteStorybookUi').then(module => ({ default: module.default?.Cn || module.Cn || (() => <div>Not Found</div>) }))) },
    'Sn': { label: 'Header Bar', component: React.lazy(() => import('../../imports/RecipeSiteStorybookUi').then(module => ({ default: module.default?.Sn || module.Sn }))) },
    'Ne': { label: 'Card Component', component: React.lazy(() => import('../../imports/RecipeSiteStorybookUi').then(module => ({ default: module.default?.Ne || module.Ne }))) },
    
    // Primitive Containers
    'Container': { label: 'Sidebar Header', component: React.lazy(() => import('../../imports/RecipeSiteStorybookUi').then(module => ({ default: module.default?.Container || module.Container }))) },
    'Container3': { label: 'Sidebar Search', component: React.lazy(() => import('../../imports/RecipeSiteStorybookUi').then(module => ({ default: module.default?.Container3 || module.Container3 }))) },
    'Container5': { label: 'Sidebar Tree', component: React.lazy(() => import('../../imports/RecipeSiteStorybookUi').then(module => ({ default: module.default?.Container5 || module.Container5 }))) },
    
    // Controls
    'Container21': { label: 'Zoom Controls', component: React.lazy(() => import('../../imports/RecipeSiteStorybookUi').then(module => ({ default: module.default?.Container21 || module.Container21 }))) },
    'Container24': { label: 'Window Controls', component: React.lazy(() => import('../../imports/RecipeSiteStorybookUi').then(module => ({ default: module.default?.Container24 || module.Container24 }))) },
};
